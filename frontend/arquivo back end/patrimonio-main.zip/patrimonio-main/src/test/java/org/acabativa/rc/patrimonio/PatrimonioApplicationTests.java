package org.acabativa.rc.patrimonio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatrimonioApplicationTests {

	@Test
	void contextLoads() {
	}

}
